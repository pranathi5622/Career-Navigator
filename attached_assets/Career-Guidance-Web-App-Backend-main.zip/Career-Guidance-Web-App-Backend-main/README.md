# Career-Guidance-Web-App
An automated career guidance web app

1. Clone
2. install dependencies
3. set openai key